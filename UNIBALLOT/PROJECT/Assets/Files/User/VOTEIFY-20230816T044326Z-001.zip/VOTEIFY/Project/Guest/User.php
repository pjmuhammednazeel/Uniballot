<?php
include("../Assets/Connection/Connection.php");
if(isset($_POST["submit"]))
{
       $name=$_POST['txt_name'];
	   $contact=$_POST['txt_contact'];
	   $email=$_POST['txt_email'];
	   $address=$_POST['txt_address'];
	   $batch=$_POST['sel_batch'];
	   $password=$_POST['txt_password'];
	   
	   $image=$_FILES['image']['name'];
	   $path=$_FILES['image']['tmp_name'];
	   move_uploaded_file($path,"../Assets/Files/User/".$image);
	   
	   $ins="insert into tbl_user(user_name,user_contact,user_email,user_address,user_image,batch_id,user_password) values('".$name."','".$contact."','".$email."','".$address."','".$batch."','".$password."')";
	   if($conn->query($ins))
	 {
	 }
}
 ?>
<html>
<head>
<title>USER REGISTRATION</title>
</head>

<body>
<h1 align="center">USER REGISTRATION</h1>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <table width="200" border="1">
    <tr>
      <td>Name</td>
      <td><label for="user_name"></label>
      <input type="text" name="user_name" id="user_name" /></td>
    </tr>
    <tr>
      <td>Contact</td>
      <td><label for="txt_contact"></label>
      <input type="text" name="txt_contact" id="txt_contact" /></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><label for="txt_email"></label>
      <input type="text" name="txt_email" id="txt_email" /></td>
    </tr>
    <tr>
      <td>Address</td>
      <td><label for="txt_address"></label>
      <input type="text" name="txt_address" id="txt_address" /></td>
    </tr>
    <tr>
      <td>Department</td>
      <td><label for="drop_dept"></label>
        <select name="drop_dept" id="drop_dept" onChange="getBatch(this.value)">
        <option value="">-----Select-----</option>
        <?php
		   $selQry = "select * from tbl_department";
		   $data = mysql_query($selQry);
		   while($row=mysql_fetch_array($data))
		   {
			       ?>
<option value="<?php echo $row["department_id"]?>"><?php echo $row["department_name"]?></option> 
<?php
		   }
		   
		  ?>
          
      </select>
    </tr>
    <tr>
      <td>Batch</td>
      <td><label for="batch"></label>
        <select name="batch" id="batch">
      </select></td>
    </tr>
    <tr>
      <td>Photo</td>
      <td><label for="image"></label>
      <input type="file" name="image" id="image" />        <label for="photo"></label></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><label for="txt_pass"></label>
      <input type="password" name="txt_pass" id="txt_pass" /></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="submit" id="submit" value="Submit" /></td>
    </tr>
  </table>
</form>
<script src="../Assets/JQ/jQuery.js"></script>
<script>
function getBatch(did)
{
	$.ajax({
		url:"../Assets/AjaxPages/AjaxBatch.php?did="+did,
		success: function(html){
			$("#batch").html(html);
		}
	});
}
</script>
</body>
</html>