<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="200" border="1">
    <tr>
      <td height="63" colspan="2">
      <img src="../Assets/Images/Screenshot 2023-03-16 121935(2) .png" width="480" height="480" alt="img" /></td>
    </tr>
    <tr>
      <td>Name</td>
      <td><p>
        <label for="name"></label>
      </p>
      <p>&nbsp; </p></td>
    </tr>
    <tr>
      <td>Contact</td>
      <td><label for="contact"></label>
      <input type="text" name="contact" id="contact" /></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><label for="email"></label>
      <input type="text" name="email" id="email" /></td>
    </tr>
    <tr>
      <td>Address</td>
      <td><label for="address"></label>
      <input type="text" name="address" id="address" /></td>
    </tr>
  </table>
</form>
</body>
</html>