<table width="200" border="1">
  <tr>
    <td>NAME</td>
    <td><form name="form2" method="post" action="">
      <label for="txt_name"></label>
      <input type="text" name="txt_name" id="txt_name">
    </form></td>
  </tr>
  <tr>
    <td>GENDER</td>
    <td><form name="form3" method="post" action="">
      <label for="txt_gender"></label>
      <input type="text" name="txt_gender" id="txt_gender">
    </form></td>
  </tr>
  <tr>
    <td>EMAIL</td>
    <td><form name="form4" method="post" action="">
      <label for="txt_password"></label>
      <input type="text" name="txt_password" id="txt_password">
    </form></td>
  </tr>
  <tr>
    <td>PASSWORD</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><form name="form1" method="post" action="">
      <input type="submit" name="txt_button" id="txt_button" value="Submit">
    </form></td>
  </tr>
</table>
