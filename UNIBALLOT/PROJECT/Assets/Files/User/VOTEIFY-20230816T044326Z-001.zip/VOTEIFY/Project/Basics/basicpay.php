<?php
$name="";
$firstname="";
$lastname="";
$gender="";
$marital="";
$department="";
$basicsalary="";

if(isset($_POST["submit"]))
{
	
	$firstname=$_POST["Fname"];
	$lastname=$_POST["Lname"];
	$name=$firstname." ".$lastname;
	$gender=$_POST["gender"];
	$marital=$_POST["marital"];
	$department=$_POST["sel_department"];
	$basicsalary=$_POST["Bsalary"];
	
	if($gender=="male")
	{
		$name="Mr ". $name;
	}
	else
	    {
			if($marital=="married")
			{
				$name="Mrs ".$name;
			}
		
			else
			{
				$name="Ms ".$name;
			}
		}
}
if($basicsalary>=10000)
{
	$ta=($basicsalary /100)*40;
	$da=($basicsalary /100)*35;
	$hra=($basicsalary /100)*30;
	$lic=($basicsalary /100)*25;
	$pf=($basicsalary /100)*20;
}
if($basicsalary>=5000 && $basicsalary<10000 )
{
	$ta=($basicsalary /100)*35;
	$da=($basicsalary /100)*30;
	$hra=($basicsalary /100)*25;
	$lic=($basicsalary /100)*20;
	$pf=($basicsalary /100)*15;
}
if($basicsalary<5000)
{
	$ta=($basicsalary /100)*30;
	$da=($basicsalary /100)*25;
	$hra=($basicsalary /100)*20;
	$lic=($basicsalary /100)*15;
	$pf=($basicsalary /100)*10;
}
$ded=($lic + $pf);
$net=($basicsalary + $ta + $da +$hra -($lic + $pf));	
	
?>
<html> 
<title> Form </title>
</head>
<body>
<form id="form1" name="form1" method="post" action="">

<table border=2>
<tr>
<td> firstname</td><td><input type="text" name="Fname">  </td>
</tr>
<tr>
<td> lastname</td><td><input type="text" name="Lname">  </td>
</tr>
<tr>
<td> gender</td><td> <input type="radio" value="male" name="gender"> male 
                 <input type="radio" value="female" name="gender"> female  </td>
</tr> 
<tr>
<td> maritial</td><td> <input type="radio" value="single" name="marital"> single 
                   <input type="radio" value="married" name="marital"> married </td>
</tr>
<tr>
<td>department </td><td><select name="sel_department">
                    <option value="">---select---</option> 
                    <option value="BCA">BCA</option>
                    <option value="Bcom">Bcom</option>
                    <option value="BA">BA</option>  
                    </select></td> 
</tr>
<tr>
<th> Basic Salary </th><td><input type="text" name="Bsalary"> </td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="submit">
            <input type="reset" name="cancel"  value="cancel">
</center>
</td>
</tr>
</table>


<table border=2>
<tr>
<th>Name</th>
<td width="30"><?php echo $name; ?> </td>
</tr>
<tr>
<th>Gender</th><td><?php echo $gender; ?> </td>
</tr>
<tr>
<th>Marital</th><td><?php echo $marital; ?> </td>
</tr>
<tr>
<th>Department</th><td><?php echo $department; ?> </td>
</tr>
<tr>
<th>Basic Salary</th><td><?php echo $basicsalary; ?> </td>
</tr>
<tr>
<th>T.A</th><td><?php echo $ta; ?> </td>
</tr>
<tr>
<th>D.A</th><td><?php echo $da; ?> </td>
</tr>
<tr>
<th>HRA</th><td><?php echo $hra; ?> </td>
</tr>
<tr>
<th>LIC</th><td><?php echo $lic; ?> </td>
</tr>
<tr>
<th>P.F</th><td><?php echo $pf; ?> </td>
</tr>
<tr>
<th>DEDUCTION</th><td> <?php echo $ded; ?> </td>
</tr>
<tr>
<th>NET</th><td> <?php echo $net; ?> </td>
</tr>
</table>
</form>
</html>